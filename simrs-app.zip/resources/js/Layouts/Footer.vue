<template>
  <footer class="main-footer">
    <div class="footer-left">
      Copyright &copy; {{ new Date().getFullYear().toString() }}
      <div class="bullet"></div>
      Developed By <a href="https://nauval.in/">Smiling.Dev</a>
    </div>
    <div class="footer-right">2.3.0</div>
  </footer>
</template>